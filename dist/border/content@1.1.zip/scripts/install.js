// Ran upon package installation

alert("Border is being installed ! You will be able to run it from the Start Menu in \"Programs > Accessories > Border\".\nThank you for downloading !\nOnofficiel.");