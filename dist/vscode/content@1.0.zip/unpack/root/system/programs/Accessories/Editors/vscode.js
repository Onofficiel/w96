let icon16 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAACglBMVEUAAAAAfr8ms/QAfL0AerwAkdYAeboAhMgAitMAcLIiqPIAbrEAhdAip/MAeMAAbLAAgtAAgdAAf9AAfc8gnvEAhcUAfL0JhsgirO0ntfUmtPUAfL4AfL0Ae7wms/QmsvQmsvQAerwAersAerslsfMAktcAktcAktcAebsAeboAeboAkNYAkNUAkNUAj9YAeLkAd7kAd7gAdrgGfMAiqu8AjtUAjtQAjtUAhswAc7UAdbcAdrcAdbcYmt8krfMAjdUAjNQAjNQAidEAeL0AdLYAdbcAO3gkrPQkq/IAjNUAidIAcbUAcrQjqvMjqfIAbrEAcbYAh9EAidQjqPMjqPIAb7IAb7IAbbIAfcYAh9EAhtEAhtIAY7Ejp/MipvIAbrEAbrAAbbAAcbgAhdEAhNAAhNAAhNAWmeYipfEAbbAAbK8AbbAAbrEAhdIAg9AAgtAAgs8Fg9QfoO8AbLAAbLAAbLAAg9EAgdAAgc8AgtEAgM8Af84goPEAgNIAfs4AfM0gn/Egn/EgoPEAidgAeswHf9McmOwgn/Ign/IFfcAhquwAersFfL8hqesmsfMmsfMAeboAeLkFer4hp+slsPQlr/Mlr/MAd7gAd7glrvMlrvMkrvMAjtQAdrcAdbckrPIkrPIkrPIAjNQAcbQAc7Ukq/Ikq/Ikq/IAitMAitMAiNEAe8IjqfIjqfIjqfIAf8cAiNIAiNIAiNIjqPIjqPIjp/IAbrEAhtEAhtEipvEipvEipvEAbrAAhNAAhNAipPEipPEipPEAgs8Ags8ho/Eho/Eho/EAgc8AgM4Ef9EdnOwhovEhofEhofEAfs4EftAcmuwgoPEgoPEEfM8cmev////jeiQ4AAAAiXRSTlMAAAAAAAAAAAAAAAAAAAAAAAAAAAABV+O9TQoCW+bwrEsFau7wBiIICXrzf9+PFg2K+PrD7d/9uUGY+/B/Lt5Czv/w+9hTAh7fLMu7Kx7fLMu8Kx7fQs7/8PvYUwIe39/9uUGY+/B/Lt5/344WDYr4+sPtBiIICXrzBWvu8AJb5vCsSwFX5L1NCgP8i/AAAAABYktHRNV+vDsTAAAAB3RJTUUH5QoYEzAOc95BnQAAAP9JREFUGNNjYIACRlExcQlJKSYYn1laRrazS05eAcpnUVRS7u7p7etXYVBVU2dlYNPQ1JowcdLkKVOnMWjr6Oqx6xsYTp9hZGwyc9ZsBtM5ZuYWllZz51nb2NrNX7CQwd5hkaOT8+IlLq5u7h5Lly1n4PD0WrFy1WpvH04uX781a9cxcPsHrN+wcVNgEA9vcMjmLVsZQsO2hUdEbt8RFR0TG7dz126G+D0JiUnJKXv3paalZ+w/cJAhMys7hy83L//Q4YLCoiNHjzEUl5TyMwiUlVccP3Hy1OkzZ6FOF6ysqj53/sLFSzUwzwnV1tVfvtLQ2AQTYBBubmlta+8QAQBQHFgzTDo1jwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMS0xMC0yNFQxOTo0ODoxNCswMDowMP+vGVEAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjEtMTAtMjRUMTk6NDg6MTQrMDA6MDCO8qHtAAAAAElFTkSuQmCC";
let icon32 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH5QoYEzEAjX1d2wAABTJJREFUWMOtl1toXEUcxn//OWd3s81ma6ypVRNaHxQbIgE1XkBQK/jgDVFRsT6IUm94CUaM2trWKl5Ko41tvaIVRUVQvNQiKq03RKyC9158kVapsVGrtjabs+fM58OabLbZ3UjMwMBwzsz/++b7X2bGmMp292cQ7QHsiDAM+w5oaTnpwLbD3jMXrBHuE/DR92dNq1hiUwa+9CPwMUA70iriZF46laa1s4Mwk9kFth5YC7YJGC5G4ofzG6eIwOIN4AMwdYFfg+gi9qSCkNbODlLZhpGZu8HeBnsKcx9LGgr+N/idG+HvPZBKzwM9idQJgERgjvysgwlSIQiALNABOg/UafBT+L/AF24EGoyszkV+JWjO6D+pBDq2l1se6QKM9skTWLQRzAUk++aDHgBmVfxXmYRkpfH+TTpqcgTu2AAijS9ejXQX0FzF+hgiNewIC1m1FZAD60BkQV8AETfOrb7o9ncBTcMnPYheUGN14yrvuhYBwCEL8FyM928i/xbSEqQZ9G+G/m2Vs297B9B0vF+GtBCpcZyfK33+O+YKJT9Un+Pwvhv5h/Fqw6sZr17EWkQH8TD0by2B974NogWvPuRvQsrURpaADzP56dcH6fSAfFmQ/bvx0Hd/IvKjFUGMlKctwEKwdQz+HBMX24AHQecDrraoVgCepRjfdeQp8wKfJB+ADq8RAzjEBlCMF/h/aZXGc5GeRrqdoo4jip/E+wsRro7sO4EezLpbO4/Z6RNvE7gIB3Y12ONAsQrDA5AWkZ++DtwZRDEkNfSET4H5uMyjyIYacnnqgquswCC424AVSIUqxtNkG2bRMtNINUAxhjgZA6xh4BmwS5Dex8di+RmjAKPloEYP6WmHvs17MbcM+T+RFgJN49RIZ6BlJvyxG/b+VXJT6HaBux+zJ5D/mxVnjnVvOf3qpiFATzsQFMjk+pDditfeqpK5AJpnQPNBYMEWisl8HP3ESQX4KKjqgwOUK+H2beAMogSyjSWgsEahzDXBtFyJUKoBkvHh81/AywrcvB7CoAHoIbDl7NuTY/AXiIq1A8hsLvLPEw11k8SN3P/NeAIT+F8CR/c68MqR+MVISzBrIgwgGoLBARgu1LMwE/n7kFYjZnPvV7B8c1mAkUCYIAtakH8A+VuQsqBSIQocFAsw+EtEVBxAqIaRNNLlSC+BnUqCce+3+6VojS7hwD+OdBUiVSkxEAa7SaJ7iONzwN6pr6c/AekFfPE6pGxhqDBxHQAc0ulIYZXCsgWzK0ln7iMIPgcWgL1cRwmQDkFagfzKnTt+OtScaeIYkC0Dfh3zNQHeALuIOHoVFLO0C7x+BLsO7GlEXGdnDUgLgBcHdvx8MqJuOQ448dJNoB3A8YAHW4lZL2g7YRb6zy5ptfExOO2afZh9AMogHVuRxpXN8JqtKDktl881u8CFtVLSuOF1wBzyHUAW4wtExOrzqq+4+2vAsii5BakXqH4hSTyhDzhkTithOlWzDkzuWn7PN2AuTTxyJVNzpSlBIkIFzJrdSiqdqlmT3H/BG9cWHQ1JHBGEjwDdiIHK6KJiPHoujO+aHAGAxZ2QJAnZ7HOYuxaxvXqq1TkSYevkCQAs6YR9BfHHb69hdgWwZbwKVLuS/4XZK+AWTNHT7MuR7XYhrUHqIvGlGJjTNjYId2P/Ps2c+9gSDU3d43TJ1+ATgHa8X0Xi56Us5ODZbQTp1C5gPWZrzWwTYtinPDsumz6Fr2OApdtKz3OzI0IL+nJNTSflZ8x435xbjdknSNH2K/IVS/4BoOlc0q9FnJsAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjEtMTAtMjRUMTk6NDk6MDArMDA6MDAoiFbiAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDIxLTEwLTI0VDE5OjQ5OjAwKzAwOjAwWdXuXgAAAABJRU5ErkJggg==";

class Vscode extends WApplication {
    constructor () {
        super();
    }

    async main(argv) {
        super.main(argv);

        this.createWindow({
            title: "Visual Studio Code",
            body: `
            <iframe src="https://vscode.dev/` + argv + `" width="100%" height="100%"></iframe>
            `,
            icon: icon16,
            initialHeight: 550,
            initialWidth: 760
        }).show();
    }
}
w96.app.register({
    command: "code",
    cls: Vscode,
    meta: {
        icon: icon32,
        friendlyName: "Visual Studio Code"
    }
});

w96.shell.mkShortcut(
  "c:/system/programs/Accessories/Editors/Visual Studio Code.link",
  icon16,
  "code"
);