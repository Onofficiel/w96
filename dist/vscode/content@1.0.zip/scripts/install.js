// Ran upon package installation

alert("VSCode is installed !<br>You are able to run it from the Start Menu<br>in \"Programs > Accessories > Editors > Visual Studio Code\".\nThank you for downloading !\nOnofficiel.");