const { register } = w96.app;
const { Theme } = w96.ui;
const { p3 } = w96.net;

let icon16 =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFOSURBVHgB1VIxTsNAEFxHKDREOomGUB0NtJZ4AKaiQcI/MLyA8AKegH8Q0tDGiAaqmCaUWEpHE9M4DSgWUNAds3t2zkIRNVlp7nS7s7Oz0hGtfhhjzoG5sTEFwj+4PvBsXPQ4acIHY/QNXmNJspha0qx4QDyx3PDecluo5aqN45MonhBl78TNy1wE2Rvp3thy1brkShYYhNqxHgu5rhprseVTFnj9cryTHbluWSA92IZi2xbggNKC1OGdgM5S8jGxj1KUzhp2tuRK1jzPSzGh9DdJMaEmLcgzKzo6Rr2omruyQs69rYo2CK0l2Y/BoTecq4sne3NEe3YGH7VAEu06ezxdd4iGR26165eG/a7dvymQgVhe7jsSVhL0A+eExeTdEfsJNaP6JNP5N46PxUeJgaH8MOS4hhgBuu7z6FegGNSuMKWsctzA4Mk5/av4AZmH3H1hFdGHAAAAAElFTkSuQmCC";

class Wail extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if (!w96.FS.exists("c:/user/appdata/Wail/config.json")) {
            if (!w96.FS.exists("c:/user/appdata/Wail"))
                w96.FS.mkdir("c:/user/appdata/Wail");
            await w96.FS.writestr(
                "c:/user/appdata/Wail/config.json",
                `{
    "theme": {
        "panelColor": "#09f"
    }
}`
            );
        }
        let configJSON = JSON.parse(
            await w96.FS.readstr("c:/user/appdata/Wail/config.json")
        );

        if (!p3.connected) await p3.connect();

        let socket = p3.createConnection("onofficiel.l51drui0hb.ppp:8989");

        let loader = w96.ui.MsgBoxSimple.idleProgress(
            "Wail",
            "Try connecting wail server..."
        );

        socket.connect().catch(() => {
            loader.closeDialog();
            loginwnd.show();
            wailLoginBody.innerHTML = "Error";
        });

        socket.on("connect", () => {
            loader.closeDialog();
            loginwnd.show();
        });

        socket.on("message", ([type, msg]) => {
            msg = JSON.parse(msg);

            if (msg.type === "login" || msg.type === "logon") {
                if (!msg.data.connected) return alert("Access denied");

                socket.send(["text", "seemsgs"]);

                wailDashboardBody.querySelector(".wail-dashboard-account").onclick =
                    () => {
                        w96.ui.MsgBoxSimple.info(
                            "Wail",
                            `<span class="bold-noaa">Account</span>
                        <br><br>
                        <b>Username:</b> <span title="Share your username with other Wailer to chat with them">${msg.data.user}</span>
                        <br>
                        <b>Password:</b> Hover this <u title="${msg.data.password}" style="color: #00f; cursor: pointer;">word</u> to see it`,
                            "OK"
                        ).dlg.setSize(320, 140);
                    };

                wailDashboardBody.querySelector(".wail-dashboard-refresh").onclick =
                    () => {
                        socket.send(["text", "seemsgs"]);
                    };

                wailDashboardBody.querySelector(".wail-dashboard-settings").onclick =
                    async () => {
                        await w96.sys.execFile("c:/user/appdata/Wail/config.json");
                    };

                wailDashboardBody.querySelector(".wail-dashboard-send").onclick =
                    () => {
                        let wailsendwnd = this.createWindow({
                            title: "Wail",
                            icon: icon16,
                            body: `
                        <div class="wail-send-root">
                            <div>
                                <label for="wail-send-receiver">Receiver</label>
                                <input
                                name="wail-send-receiver"
                                type="text"
                                class="wail-send-receiver-input"
                                />
                            </div>
                            <div>
                                <label for="wail-send-message">Message</label>
                                <textarea
                                name="wail-send-message"
                                class="wail-send-message-input"
                                cols="30"
                                rows="10"
                                ></textarea>
                            </div>
                            <div>
                                <button class="wail-send-send-button">Send</button>
                            </div>
                            </div>

                            <style>
                            .wail-send-root {
                                width: 100%;
                                height: 100%;

                                display: flex;
                                flex-direction: column;
                                justify-content: space-evenly;
                            }
                            .wail-send-message-input {
                                resize: none;
                                height: 100%;
                            }
                            .wail-send-root > div:nth-child(2) {
                                flex: 1;
                            }
                            .wail-send-root > div > *:not(button) {
                                display: block;
                                width: 100%;
                            }
                            </style>
                        `,
                        });
                        let wailSendBody = wailsendwnd.getBodyContainer();

                        wailSendBody.querySelector(".wail-send-send-button").onclick =
                            () => {
                                socket.send([
                                    "type",
                                    `sendmsg {"receiver": "${wailSendBody.querySelector(".wail-send-receiver-input")
                                        .value
                                    }", "message": "${wailSendBody.querySelector(".wail-send-message-input").value
                                    }"}`,
                                ]);
                                wailsendwnd.close();
                            };

                        wailsendwnd.show();
                    };

                loginwnd.close();
                dashboardwnd.show();
            }
            if (msg.type === "logout") {
                dashboardwnd.close();
                w96.sys.execCmd("wail");
            }
            if (msg.type === "seemsgs") {
                wailDashboardBody.querySelector(
                    ".wail-dashboard-message-container"
                ).innerHTML = "";

                for (let i in msg.data.messages) {
                    wailDashboardBody.querySelector(
                        ".wail-dashboard-message-container"
                    ).innerHTML += `<div class="wail-dashboard-message-box">
                            <span class="wail-dashboard-message-close-btn material-icons-outlined">close</span>
                            <span class="wail-dashboard-message-title">
                                ${msg.data.messages[i].sender}
                            </span>
                            <p>
                                ${msg.data.messages[i].message}
                            </p>
                        </div>`;
                }

                for (let i = 0; i < document.querySelectorAll(".wail-dashboard-message-close-btn").length; i++) {
                    document.querySelectorAll(".wail-dashboard-message-close-btn")[i].onclick = () => {
                        w96.ui.MsgBoxSimple.confirm("Do you really want to delete this message ?", (ok) => {
                            if (ok) socket.send(["text", `remmsg {"id": ${i}}`]);
                        }, icon16);
                        
                    };
                }
            }
            if (msg.type === "remmsg") {
                if (!msg.data.removed)
                    return alert("Error : The message wasn't deleted.");

                socket.send(["text", "seemsgs"]);
            }
            if (msg.type === "sendmsg") {
                if (!msg.data.sended)
                    return alert("An error occured while sending the message.");

                alert("Message succesfully sended to " + msg.data.receiver);
            }
        });

        const loginwnd = this.createWindow({
            title: "Wail",
            icon: icon16,
            initialHeight: 570,
            initialWidth: 370,
            resizable: false,
            body: `
      <div class="wail-root">
        <div class="wail-login-header">
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVcAAADcCAYAAADEMeK3AAAACXBIWXMAADddAAA3XQEZgEZdAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABzHSURBVHgB7Z0/lxTXmcZfdHxWyXqNJAdaJ5SC1SbSApaTVUKT2Mn6MBxv4kjNJwA+ATOfAPgE9ETeZM1w5GSdUJNYiTHDkRKRUASWHay9oyMlUsLep6tqKJrunv5z73vvfe/zO6doRowkpm/fp9567vvnjETgxYsXlXu50F3nutezgysUxzNX467n7jrC12fOnKmFELIRbl9j71bS7me8nuteq+5bQu/vpruwt59Iu68bt6+PJAJnRIHuTccbfsVdO/LyzU6Ro+46dFftFqYRQshrdEES9vN5d40k3X0Nsa3d9UAU93RQcXVv/si9fCLtAoS8Y4WkkXZh9hnZkpKZCZLGku+erqXdzxMJSBBxdYswllZUR2KLRii0pDC6ICl3QZ1H46477noQIpr1Kq6dqN6StB/7fdG4a89dB25hjoUQQ3RR6nV33RBbgjqPxl0Td931uZe9iGt3Z4OojqQ8Gmmj2T36syR3ChPVWRpp9/FEPLCVuHYLAVG9IQRMhCJLMqRwUZ1lIh728cbi6hYDxvZ9KcMCWIfGXRO3MHtCSOJQVBfSyJZR7Ebi6hYEh1UwgrkYi2nE4yMGIb7p7Lx7wgBpGbubBkpri6tbENgAu0JWZSK0CkhCdNEqRHVHyCocuOvauodda4krhXVjGnfddItzIIREpItWYefxqXM9UFh0eR2BfWPVb6SwbkXlrvvde0hIFNzn77Z7eSgU1k3AGdPDLupfiZUiVwqrV3AHvEqbgGjRlakiWr0gZFuO3N69uMo3nhq5Uli9098BKyEkMF1WD6JVCqsfLrj39N4q37hUXDt/ZleIbyp3PXbvLw8USDC6zxeEtRLik7F7b0/N7V9oC3SRFRcmPGP3mLEvhHikS5ecCAnJ5WU9RpZFrqX0CIjNhAddxCcUVjXuLTvgmiuuXQOWsRAtdld5zCDkNCisqlTSBqFzec0WoB0QFVoEZGM6j/W+EG3m2gPzIlfUGVdCYjDpTncJWYvuc7PSKTbxztzo9ZXItYtanwmJCSpALjIPlqwKnzaT4LXodTZy5cFKfGCQr1UJQoqHwhqf17TzRFy7u99YSApU7rothJxCV9JaCYnNqKsLOGEYuY6EpMRKicqkXLqsHn5G0uH68IsTz9Ut1GOJWCJ39Lf2ev6NBOXcD91t3l0X3nbP329K6tB/JXPJxWdtvmn39fH3Yfc29vL5d1yE+M8SE+zX9/rOWVNxjXWQdfydyN0vRO580f5eGywIFmP0E5FL7vXCO5IimLN+WQgZ0NW3jyUx6r+IPHFietB0oqq8r7Gnd845A/SjNoiKAFqLYpDAibji0ULN4+tFdfeRJAUWY/y+yCfvR1uYRZwsGCGdHZBM2hVE9EETL0haBPZyBJE9CYZ6ccXjxUgUwGPC5d+1rykzFdl/jf6Y0fPK4wYpG7df8ZRZSWQQpe65AKn+SpIFwnr/56pPpSd7tRfXF6JALsI6BI8Ytz9OIpLF0MNrQoomhRagOYjqLBDYnUq0mOa8nunSBx5KYPC4cPG3eQnrkBsfuqPAD6KL7NIuPMQ2sYt8sIf3/uQe/z+X7Dj7DyKPf6W2f6c2HlKxVDIEbn6Wr7ACfKAQdeOuHREWeZRNtPXH5x7BUY7CCpCtcPX3osV5/AJxrSQwENXJU8meqa3xaftIFInXEpVJGcQs8sHnHZ/7nIMjgIO3uzo3h2nACnE9L4GJKEZBQJYDIvFIMHotkyjrfu0wvayebVD6WSr8ciZ08QDC8bcmYhKcQD78jyjFCO+xsKAstDME4K/CBkO0Z42Hv1TJAnoLkWvQBiEWF6cHPxs+gBFy+8ZCiqHLa61EEavCCg51shx+FNxzfWJYXAE+gBEsguvsmlUU10URWAGWgyIl7/itU0drb0tKFRuhwGGdssBCWEdCzNMdZKn1/MD5yORLMY2SuJ4NLq6lgBSVfd0PpWo0Q6Kh1vUK6VaWDq9iE1xcM+g85Y0burm8I1oDRXBFFMDn9lotRYCCAg0gro0EpPpHKQZkRih/QHeEmKWbi1WJArADcs9jXZXqn0SDZ8Ej10s/kaLAo5ViFdclIZYZiQJWinxW5UolGnwNcT2SgCAET6SzlBqK0SsjV9uoWAKl2AFASY+O0RUL4vq1BGbnPSkKRAL7OpHAWY7iNk3wtT363+j9MlRR6ozV4JfgkStA8+nSUExnGQkxR3fTDH5giab1JXFFJ9B7jl9UxLVEa0DRew3eG4JEYSSBKc1rBaN3RYMav6iIKxgVdrAFMPpCgZEQiwQ/rCzJDgBofK+UGjrV1De60SG1BIbWQDAq5ruapJLA7BuvxJpFyRI47hva96lYhxIYdAA/l9bQv+Ag71UpOhgJMUN3swx6mKX42UwGJWvyREt7cT0QBa4VGL0qdeAZCbHESAJjuTHLPCCsSiNeTrR0Kq4ujIVH0EhgSisoAEpD3HioZYuRBOYwo+GCPsAkZyXq/jfDCq19CQzuHlp1vamgFCFcoO9qiuA3y5wmt/pAyRKoh03sh+JaiwJjvTtIEsDbUqjZDu7REVVGEpiSbAFMDFGyBF4JUE/EtTvhOpbAKNX1JsWhzsEBxdUAGgMoUZWFm34pjPXOeurhF7ONW2gNBIC+K1mD8CWvf5eiUDrrOZqdazcrripZA0r1vcnAdCyyBsGLB0o6zELLU9gCCrwWmL4irlrWwCeF+a7wXBXG3aCY4JyQ3AkfuRbktyo2japn/8G8fq4PJDC4kxRnDfxVNLgsJFu6eVmVBARea0niqnTG03TprK8wT1wnEpgSG7koPYrxUCtvGLV6BJaAks7MDUjniSsUOHzWQGE9XnFCqwAnE+TNSAJTkt+q2Cxq7lnVa+LaNXIJ3imrtEMtFhOQFWDxgEeUznaavlHLLItmaAVPySrNGlD0umgN5MtIAlOKLaBoCdSL/mCRuOqkZBVmDdB3JYtg8YBfFC2BhYHoXHFlj9cwKEUNIyE5wuIBj2j3bp3HstHawVOySrMGlIoJeKiVJywe8MiOTsb30if8ZeI6EQVKGv+iVExwlsUEWcI0LE/s6H36lwagP1j0B7AG3CatJfBjJqyB3UdSDCgmUFh8FBNMZAO6bINK2s2O1x9J23WrvzQ5HlwYAd90F75uOvsqe1g84BetNE/3+Vsauf5AlgNlHklA+vEvz8O35UsCPJopiOtKUdBgnMgVaTf3SPQFdGPc379PG8SFccZHyzywhGHU6pGYhQNDThNXKPNtCczVSuTO51IEsYsJuihpR1pBHUne4EYwksHP4X4+vNTSCi42wFEGEe5IAlOK3xpjnMsilnmu0rXQCl5QUFKP1xjFBPi9u26466H78pm0N8yR2GXkrhvuws/7f/i5u5+/kjRh8YAnFIuT6tO+4Q05neBZAyX1eNUsJkDupLvuSRmCuoyRtD//M/d+PE5QaEcSmFJsAaXerfVs79Z5rCKutShQUjms0iMaRBWR21gy8lEVgL/ZCy0i2rFEhMUD/ojZu3Uep4qrVo/XkibDKkURlZDTGLnrnhM4CO3tSNFs8MOsQ512l9FRTOusV/mmVSJXELzXACLXUqwBpWICsjqVtB4tRPaessgGLx6o/yxFoNSo5WgVSwCsKq7Bew1AWJVC+ugoFROQzRiLrsgGj1ybb8U8itWeh6t+46riqtLjtaRGLnUhj2oZM5bAIuv+u32hRjBKKR5QLKNfOdBcSVzZyMU/JdV5Z87YXcgwuCX+qSQwpXzOlKqymnWKVFaNXAEbuXhEqZiA+AHZFrvdwddY/DGSwJTi78fu3TqPdcRVpcdrKY1cSipHNEQlbXaBL6sg+GFWCTdxxaqstQLMlcVVyxooJSWrtCmcxhi7a6sc2UFfh6CUELlq5cif1qhllnUiV8BqLY/Qd82aStoo9vaGc8sorJ5QKp9fW/vWFVcVa2Csk68WHUauJkB+7OMNbILg4vqkgM8XqrJSadQyy1ri2iXPNhKYUhq5sJjADJW0Ajte499h8YAHFNM3a1mTdSNXENwaQDFBCdYAigmaQvrYFgCsgXtrpGyNJDAlzMxSCsTqVauyhmwirirVWqWkZB0yerXGbpdNsNCH7YoHgjbTKeHGrTg+e6OAcm1x1WrkcqWQai36riYZS5tNUC34c/qtHkitUcssm0SuILg1UEoLQhYTmAUCukhgw/utBTwRKVZlbTQwYFNxnUhgSrEGELmyiYtZKpkvsOFnZpVQPPCuaFDLhmwqrmzk4olpMUEBBw8FU8lAYFk84IdpPvybosHG7VY3EteuWiv8bC29+eNReUJrwDqVvBRYCqsHlHq3Hm8zTfi06a/L4NhtT2B43PUPJVmm/We/jzMqRDFJPDSVtGN3gp9XFHGYlVjv1nlsI64T4dhtL6QUacD/PXjeRtP4e6HRcgqeMB4BL7zdvb7T9qDov86Iyl3XJTDWiwew/qlWZQ3ZWFxhDbjHnFoCR69IErYurogIER3GitAgnhDSu1+kO4K5/zuCg8b98qj9PTYaLnxOFH24pLHu4aeegtWzTeQKEDaPJCB9Ixfr0ytRTKAtrhAsCOqdL/LNWEC2Ba7J0/ZrfF7QmwJ+fYlCW0LxQMpVWUM2zRY4+QuIAiXkvGoXE0CM3vsvkd1HtlLBEN2O6/Znu1aXV6Rh3W9NvSpryFbi2p2kNRKYEsRV63EcUc3l37XCYzm/Fj8bbiAX/9v9vJ+K7D+VIjCfgqVnCWxd5r9t5AqCn37i8MJ6IxeNYgJsvIu/TddXDcVJNPsb+yJrvXhAsSqrkS3xIa4cu+2JkAcR8FYRwZVcDYaoHSKL98GqL2k9ct3RyX33EjBuLa5ajVxKqNYKVUyw53zVG38Q0gEBQhR78zN7frNldvSKirwEjD4iVxDcGihh7HaIx3UI6+4jIXNAit/UJjEiStYPs1Icn70MX+JaS2BKaOTie5MjH5TCupzpAd+n7U0od6wXD6Q4PnsZvsSVY7c90BcT+AD/nWtbFe+VBW5CsApy9mItFw+kOj57GV7ElWO3/eFrMgHSrdjKcD36NLUcc2OtFw8opmPW4glfkSvg2G0P+NjYyAzgbK7NwPuG3Nj9LyUrrPutSoFV3QWKXvAprhy77YFtD7UgDtZ7MWgwPszLh7WcKYCqLKVUzI17t87Dm7h2Sbfhe7xWYpptiwkgCIxa/QAfNheBtVwYkkujlll8Rq6AY7c9sOnBBA7ESmiUrAkE9m7iTwLTaRaGbQGlxthHPqqyhvgW11oCA2G13mtg02ICpF4xavXPjc/S9mAtC6tiCqb33Bqv4qpVrWU9a2DTR7zcDmFyAgKbqohZPsxSzG33fmbkO3IFXk3heViPXDd5tEfESksgHHj0vvr7NJ8MLBcP5FaVNSSEuKo0crFcrbVJMUEJc5NiMy3MqCU5LN9Uc6vKGhJCXDl22wPrFhMwatUB73NKGQRoMWh1SkeOVVlDvIsrx277YV1/z3ofz5RABkEqNzPLJa9a9p/TrCBP2yEiVxA8Jasfu22V6RC+NXj2rRBFUpnkcGg4v1Uppz2YVoUS14kocM1wG0L4e+ts3udMwVIF64MDrthYTcNCVVYO47OXEURc2cjFD9ZHJOfOdBx5xAIDy8UDimcqtQQiVOQKgje8s97IxfIjnxVi5r9aLh7IZXz2MkKKKxu5bElpgwRzBfZADP/V6s03p/HZywgmru6OgIyBRgJjuZGL5cjEErHyX63efHNt1DJLyMgVsJHLFvicTEDCcvBc33+1evNVrMoKmjIaWlw5dntLDlkckA3If9USPNPFA++KBrUEJqi4cuz29tB3zYe+/4CG/2o1k2R6SP2maBC8B0royBVw7PYWrFoJZLmgIidg49z8TIJj9TBLqXfrcYhGLbNoiGstgbHcyGXdYgISn8nT8P6rVb81196t89AQV47d3pL6r0IyYzfguB2rxQM4O8m9KmtIcHHVqtay3MiFxQT5AQEMNd7cbNRqJAWrRyNyBeFTsn5s13dkx6s8QeS69yfxjtWbrYWqrCFa4qoShl+txCQsJsgXjDn3PX7HYgaJlaqsISri2t0pagmM1WqtVTy2t4xPxM0Z9B/w6b9avNkqWgIqgR7QilwBG7lswWmPgtbHjeeMz/xXq8UDilVZjSihKa61KGB1eCGtgbzB+vnwX60WD+zoHEirWQJATVw5dns7OCMrf+C/rjthYhaLh1k7epk+apYA0IxcAcdubwiLCWyA7lnb+K8Wn2ByHp+9DG1x5djtLWAxQf70/uum/67Jw6yMx2cvQ1tcOXZ7C5Y9EvJAKx8gkJv0H7AqrDmPz16Gqrhy7PZ2LCsmUOokRDwB/3VdH92k31qJFrUoox25guC+K+6EFnu8MmPAFlf/Zz3/1WLxgNIBdN0FdqrEEFeVEzuLB1uWp32WCNZznfEw1tYeVVlKQVDwgG4e6uLKsdvbwSYutoA1sPfo9O+zWDxgrVHLLDEiVxDcXLZarcXI1R5oT3ia/3poMFNEqTH2kWZV1pBY4sqx2xvCYgKbwB5Ylsdc/1lMoZgyqdIYex5RxLW7kzQSGIuNXHAAMiuw2JQU3bzBui7Kf8XaYrqsJRRz0VWrsobEilwBx25vCKKc/acvhRZNmVMcwY33nvm3q4O1fO83bYks1nPaD9ZZBpc/FXNYrcoackYi8eLFi5F7eSiBwQeTUZ0uF94Wuf3xywMLzJTa+6P7pH8rhEx59muV4oGJE9drEolokSvHbtsE6TUPf/nqSfD4/fafMYolwHJV1pCYtgDg2G1j3PhwfrUYNtPtfxdC1HLQXQAXzW8FscWVjVyMsawMF9kbEF9SNkoHzVGjVhBbXGtRsAYsj93OjVsf2SxNJqsB28jS+OxlRBVXrUYutAbSAU8S939O/7VUFM9AaolM7MgVBA/fcae0OnY7R7Ae90ZCCsTa+OxlpCCuE1HA6tjtXMGhBv3XsrA4PnsZ0cVVq5GL1bHbOYPsAR42loP1Ri2zpBC5Ao7dLhTYA4hoiH0Uq7KCn+OsQiriWosCVocX5szUf70spABG74oGtSRCEuLKsdtlg6cKpGgRu0yfHHVGEUVpjD2PVCJXoDJ2m9ZAmux+RP/VMkq9W49jNmqZJSVxVanWYgJ7utz/Bf1Xq1jv3TqPlMSVY7cLZ1pg8AshxlBs1BK9KmtIMuKqlZLFaq20wZMFG7zYQskSALUkREqRKwie/MtGLumD4gLeBO2gtN+SqMoakpq4qoT1bOSSPnc+pv9qAfTyLaF36zySEleO3SY9eMJgg+38UUyxS8pvBalFroBjt8kURDzMf80XxYOsJjVLAKQorhy7TU6A/8oGL3ly62eiRXKWAEhOXDl2m8zCBtv5gahV8eB4IgmSYuQKOHabnMAG2/mhGLUm06hlllTFlbO1yCuwwXY+IENAcW8laQmAJMVVq5HLFVZrZQUbbOeB8iHkHUmUVCNXEPyOxEYu+cEG22kDYa30RiolVzgwJGVxnUhgaA3kCewB3hTTA0Ufu7pRazLtBeeRsriqNHK5/m9CMgORERu8pAeKPhTBQdZEEiZZcdUau62cMmIerSm7bLCdFsp2AEiuImuWlCNXoHISeJ2HJFnCBttpEMEOAHclcVIX14kogIMtNgnxw4W3RRU22I4L3ntlOwBMUj7I6klaXLUauQAOydseHDIpzUl65f8JgeUBVxym03t17QCwJxmQeuQKVEY30HvdnljvHxtsxwE+a4T2nVlErSAHcVVLEmaKz3bE7JOLRjw84NID7/VunPc7i6gVJC+umtYAW9xtR+xmONjsXL/w4AA4krBmE7WCHCJXoFY/jPJK2gPrg0fzCN7ba1Bgw4J5WHfiWDCNZBS1glzEdSIKBQU9tAfWJ6V0NgpsGCCsk0sSi7s5Ra0gC3HtrAG1vDZWAK0H0nFSi/YpsH7BexlRWFGNlWyDlkXkErmCiSgCseAJ9GogoknBEpiFAuuHiIdXPVclQ7IR1+6RoBZF4L9ycy4HUes44THYEAU22t4MvGewyCIL6yTVZtincUYy4sWLFyP38lCU2X3knPRHQuaAzZeyuPY034hc/tS9fitkBXDThDUWebxO467LuXmtPTnZAn0T7VqU4ePlfCCqOQgrgG3x+D/z+fvGBPnKj3+VxNyyvVyFFWQVuYJY0StgBPuSvqY8Ra/1NCZPRW7+QeT4eyEDYAMgiEhk2gOyA25IxmQnrsAJ7MS9fCIRuPN5K7Clb8xEIpuNgU0AgT14LkTaaPXepWRulsgOyH4IU67ieta9PHPXWYlA6f5dLj7rKiCK3ftjuWuZWLQKkHZ5MWc7oCcrz7VHO+91lpL9O0vCCvCzwN4ocfAhCj+e/Tq5nz1rn3VIlpFrj4tgH7uXCxKRUiKfPi0HvW+tgicSWD5YU8skZgEMgbDuihFyF9eRRDrcGgL/tfdiLZJIWo4aVkUWN8brH8TtXrYETHI11VU5a3EFTmBRFnddEsDippx2QPqpfhPsFOjXs/4q3ycTPHFgDW98kPQaNpJxPusiLIgrDrUQvUa1B4ZYEFlEq7ABEo1y1MFa7n/phPYvkgVYN7SAHP9L8jfGRgwKK8heXIET2Mq9wH+Nkj2wCIgsNuNdZxkc/U2yAKJ662dMtl9Ev6YpCm1GgtpjJjNgHibEFTiBRcLxbUkUbErkVGJTpii02Ji3fspIdR2Ov2sF9kHTrqn2uuJACg2GLrk12zmXnXUDYb2ca9+AVTAjriAl/3UZ/aY8/OrlptQuSug35vkfZxXpJA3W9ejvL9cVN1RfgtuvF17Pv9P+PuM1My+swJS4Aiew8F9Hkhn9xsQrDk++/k68c+6H7WM/Tv0T35jYfElZPNswXFvcRJ9/s/z7sU44iKoGr4YoQliBRXHFpoT/WgnJEYzyOHDXfeEaWqMYYQXmxBV0B1yIYCshOXFSU841NEdRwgqyLH89je70EQnJanO3yNZMN1//xWANGyG500ibFVCMsAKT4goosNlxczYlZ7CGRW1KY2DtTOaxnoZZcQXdnZICmz6oKZ/M+wNsSnddlIiNesjG7EuhwgpMeq6z0L9LmgO3+VYaQOfWcde93BKSA6aasGxCEeIKKLBJ0j8yrvxk4dYRZc7MJEiXxl3XupFMRWPaFhjCA5LkaNx1dR1hBQOrZ19IatTS3ixrIeWIK+gElv5dfBrZwovrfNix++1NoZ+eAlgDHEgW66/OoxhbYBb6d9FA5HnV1yak3RMdrOe10tKsVqGoyHVIZ7Yjim2EaFGL59PjLopF4QGjWF36aLW4/NVVKVZcAf07Ve52j41BBND9d9G0BzdLrmV4ammLAu4IWUixtsAs7vFyLK1NUAnxzU3NjejWckfa9pOVEJ80wkyAlaG4Duj8u113fSLEB420/mqUx0beML0xnbZcet7qulBc58BcSi8gI2M3lA2wDl0jdfT5rYSsQz/C/k4K65gbFNclMPLZiEYSfHTsnkpGwvVcBYqqByiuK0CRXRn0Yk1+Q3I9FwL7BgeCE4rq9lBc14CbciG1tNFqIxnh1nPkXsZCj72WthdALcQbFNcN6EQWG3IkZVOLgU1ZqGWAKPWB8NE/GBTXLRhkF1yScjYlNiIeHQ8sRjrdYebYXVfE3po20q5dzSg1PBRXTwweMa0KbS1tpFOMH9cJ7UhaoR1JntTuOpT2ZshKKkUorgHohBbXJcnbOqil3ZiT0htydIMvIbYoUDgv6a4rBBRrVksbofKRPxIUVwU6scXG7KPaC5Im/cbE6wE35nIG61pJK7j4vdZIcKxNI+1aPelej7hm6UBxjcAgChq+nu/+uJp59UkzeMX1XF5u0IYbc3sWrO257nX2msexvGxA08jLNRuu1TFb+6XP/wP0+VKAj0PqCwAAAABJRU5ErkJggg=="
            alt="Wail Logo"
          />
          <h1 style="font-size: 3em;">Your personal messanger.</h1>
        </div>

        <div class="wail-login-form">
          <h3>Connection</h3>
          <input type="text" placeholder="Username" id="wail-login-username-input" />
          <input
            type="password"
            placeholder="Password"
            id="wail-login-password-input"
          />
          <div class="wail-login-button-container">
            <input type="button" id="wail-login-connect-button" value="Connect" />
            <input type="button" id="wail-login-register-button" value="Register" />
          </div>
        </div>
      </div>

      <style>
        .wail-root {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          align-items: center;

          width: 100%;
          height: 100%;

          font-family: Arial, Helvetica, sans-serif;
          color: #09f;
        }
        .wail-login-form, .wail-login-header {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
        }
        .wail-login-form > h3{
          font-size: 2em;
        }
        .wail-login-form > input[type="text"], .wail-login-form > input[type="password"] {
          color: #09f;
          background-color: #fff;
        }
        .wail-login-form > .wail-login-button-container > input[type="button"]:hover {
          border: 5px solid #09f;
          border-radius: 20px;
          background-color: #fff0;
          color: #09f;
        }
        .wail-login-form > input[type="text"], .wail-login-form > input[type="password"] {
          padding: 0 15px;
          width: 300px;
          font-size: 1.5em;
        }
        .wail-login-form > input[type="text"]::placeholder, .wail-login-form > input[type="password"]::placeholder {
          color: #09f;
        }
        .wail-login-form > .wail-login-button-container > input[type="button"] {
          display: inline;
          background-color: #09f;
          border: 0 solid #0000;
          border-radius: 20px;
          color: #fff;
          padding: 0 15px;
          transition: all .5s ease;
        }
        .wail-login-form > *, .wail-login-button-container > * {
          margin: 5px;
          height: 40px;
        }
        .wail-login-button-container > * {
          font-size: 1.5em;
        }
      </style>   
        `,
            center: true,
            taskbar: true,
        });

        let wailLoginBody = loginwnd.getBodyContainer();

        socket.on("connect", () => {
            wailLoginBody.querySelector("#wail-login-connect-button").onclick =
                () => {
                    socket.send([
                        "text",
                        `login {"username": "${wailLoginBody.querySelector("#wail-login-username-input").value
                        }", "password": "${wailLoginBody.querySelector("#wail-login-password-input").value
                        }"}`,
                    ]);
                };

            wailLoginBody.querySelector("#wail-login-register-button").onclick =
                () => {
                    socket.send([
                        "text",
                        `logon {"username": "${wailLoginBody.querySelector("#wail-login-username-input").value
                        }", "password": "${wailLoginBody.querySelector("#wail-login-password-input").value
                        }"}`,
                    ]);
                };
        });

        const dashboardwnd = this.createWindow({
            title: "Wail",
            icon: icon16,
            initialHeight: 570,
            initialWidth: 770,
            body: `
            <div class="wail-dashboard-root">
                <div class="wail-dashboard-left-panel">
                    <div>
                    <span class="material-icons-outlined wail-dashboard-account">account_circle</span>
                    <span class="material-icons-outlined wail-dashboard-refresh">refresh</span>
                    <span class="material-icons-outlined wail-dashboard-send">send</span>
                    </div>

                    <div>
                    <span class="material-icons-outlined wail-dashboard-settings">settings</span>
                    </div>
                </div>
                <div class="wail-dashboard-message-container"></div>
                </div>

                <style>
                    .wail-dashboard-left-panel {
                        color: #fff;
                        background-color: ${configJSON.theme.panelColor};
                        width: 80px;
                        display: flex;
                        flex-direction: column;

                        align-items: center;
                        justify-content: space-between;

                        padding: 20px 0;
                    }
                    .wail-dashboard-left-panel > * > .material-icons-outlined {
                        display: block;
                        font-size: 30px;
                        padding: 10px 0;
                        user-select: none;
                    }

                    .material-icons-outlined {
                        cursor: pointer;
                    }
                    .wail-dashboard-root {
                        font-family: Arial, Helvetica, sans-serif;

                        width: 100%;
                        height: 100%;
                        background: #fff;

                        display: flex;
                        flex-direction: row;

                        align-items: stretch;
                    }
                    .wail-dashboard-message-container {
                        flex: 1;

                        display: flex;
                        flex-direction: column;

                        justify-content: flex-start;
                        align-items: stretch;

                        overflow-y: auto;
                    }
                    .wail-dashboard-message-container > .wail-dashboard-message-box {
                        background-color: #dadada;
                        min-height: 100px;

                        margin: 10px;
                        padding: 10px;

                        border-radius: 10px;
                    }
                    .wail-dashboard-message-container > .wail-dashboard-message-box > .wail-dashboard-message-title {
                        font-weight: bold;
                        font-size: 20px;
                    }
                    .wail-dashboard-message-container > .wail-dashboard-message-box > p {
                        font-size: 18px;
                    }
                </style>

                <link
                href="https://fonts.googleapis.com/css?family=Material+Icons+Outlined"
                rel="stylesheet"
                />

            `,
        });

        let wailDashboardBody = dashboardwnd.getBodyContainer();
    }
}

register({
    command: "wail",
    type: "gui",
    cls: Wail,
    meta: {
        icon: Theme.getIconUrl("exec"),
        friendlyName: "Wail",
    },
});

w96.shell.mkShortcut("c:/system/programs/Network/Wail.link", icon16, "wail");
