// Ran upon package installation

alert("Wail is installed !<br>You are able to run it from the Start Menu<br>in \"Programs > Network > Wail\".\nWail is in beta so the server will not be up all the day.\nThank you for downloading !\nOnofficiel.");