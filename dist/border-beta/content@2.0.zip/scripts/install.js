alert("Thanks for installing Border beta! As the name suggests, it is a WIP build so bugs are to be expected");
w96.sys.execCmd("border-beta");
