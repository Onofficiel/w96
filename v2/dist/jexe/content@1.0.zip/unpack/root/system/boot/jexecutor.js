const { register } = w96.app;
const { Theme } = w96.ui;
class Jexe extends WApplication {
    constructor() {
        super();
    }
    
    async main(argv) {
        super.main(argv);

        eval(await w96.FS.readstr(argv.toString()));
    }
}
register({
    command: "jexe",
    filters: ["jexe"],
    cls: Jexe,
    meta: {
        icon: Theme.getIconUrl("exec"),
        friendlyName: "JS Executor"
    }
});