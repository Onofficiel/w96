// Ran upon package installation
if (w96.FS.exists("c:/user/appdata/Border/config.json"))
   w96.FS.rm("c:/user/appdata/Border/config.json");

alert("Border is installed !<br>You are able to run it from the Start Menu<br>in \"Programs > Accessories > Border(.link)\".\nThank you for downloading !\nOnofficiel.");