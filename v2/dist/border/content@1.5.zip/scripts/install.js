// Ran upon package installation

alert("Border is installed !<br>You are able to run it from the Start Menu<br>in \"Programs > Accessories > Border\".\nThank you for downloading !\nOnofficiel.");
alert("/!\ Please if you had an other version of Border before, delete other \"border@1.#.js\" file than the newer version if you have problems with this ping me on discord \"Kelbaz#7094\".");

if (w96.FS.exists("c:/user/appdata/Border/config.json")) {
   w96.FS.rm("c:/user/appdata/Border/config.json");
}